# Inputs Viewer

Shows player inputs during gameplay. Configure in the pause menu.

This mod is inspired by the Key Viewer feature in <cy>ADOFAI Tweaks</c> (a mod for <cj>A Dance of</c> <cr>Fire</c> <cj>and Ice</c>).

Untested on MacOS and Android