# Inputs Viewer iOS port preparation

This source preparation adds an iOS 2.2081 compatibility entry to `mod.json` and an iOS build job to the GitHub Actions matrix. The CMake macOS universal-architecture setting is now skipped when the toolchain identifies the target as iOS.

## Important status

This is a **port-preparation patch**, not a verified iOS binary. It must be built with a Geode SDK/toolchain that supports the `iOS` target, then tested in Geometry Dash 2.2081 on an actual iOS device. The existing gameplay hooks are shared C++ Geode hooks; no iOS-specific implementation was present in the supplied source. A successful build is still required to confirm that all hook bindings and SDK APIs are available for this target.

## Build validation

1. Use the Geode build action with `target: iOS` on a macOS runner.
2. Confirm the generated mod package contains the iOS binary and the updated manifest.
3. Install on a test device running Geometry Dash 2.2081 and check classic/platformer input display, pause-menu settings, and input press/release tracking.

Do not publish the manifest as proof of compatibility until those checks pass.
